import React, { useEffect } from "react";
import { useState } from "react";
import DynamicFrom, {
  DynamicFromValidator,
} from "../../comp/DynamicFrom/DynamicFrom";
import "./Home.css";

const Home = () => {
  const [inputArr, setInputArr] = useState([
 
  ]);

  const convertDbToForm = (obj)=>{
    let newObj = obj;
    switch (obj.inputType) {
      case 'text':
        newObj =  {
          uniqueValue: obj.id,
          inputType: "text",
          inputValue: obj.value,
          inputName: "userName",
          placeholder: "Please enter name.",
          label: obj.label,
          autofocus: false,
          disabled: false,
          autocomplete: false,
          readonly: false,
          validator: {
            isRequired: true,
            arrayErrors: [],
            arrayFunctions: [
              DynamicFromValidator.checkEmpty,
              DynamicFromValidator.maxLength(20),
              DynamicFromValidator.minLength(10),
              DynamicFromValidator.checkLetterExists("-"),
              // DynamicFromValidator.emailValidation,
            ],
          },
        };
        break;
     
        case 'email':
        newObj =  {
          uniqueValue: obj.id,
          inputType: "email",
          inputValue: obj.value,
          inputName: "Email",
          placeholder: "Please enter email.",
          label: obj.label,
          autofocus: false,
          disabled: false,
          autocomplete: false,
          readonly: false,
          validator: {
            isRequired: true,
            arrayErrors: [],
            arrayFunctions: [
              DynamicFromValidator.checkEmpty,
              DynamicFromValidator.maxLength(20),
              DynamicFromValidator.minLength(10),
              DynamicFromValidator.checkLetterExists("-"),
              // DynamicFromValidator.emailValidation,
            ],
          },
        };
        break;
    
     
        case 'number':
        newObj =  {
          uniqueValue: obj.id,
          inputType: "number",
          inputValue: obj.value,
          inputName: "number",
          placeholder: "Please enter number.",
          label: obj.label,
          autofocus: false,
          disabled: false,
          autocomplete: false,
          readonly: false,
          validator: {
            isRequired: true,
            arrayErrors: [],
            arrayFunctions: [
              DynamicFromValidator.checkEmpty,
              DynamicFromValidator.maxLength(20),
              DynamicFromValidator.minLength(10),
              DynamicFromValidator.checkLetterExists("-"),
              // DynamicFromValidator.emailValidation,
            ],
          },
        };
        break;
        
        
    
     
        case 'checkbox':
        newObj =    {
          uniqueValue: obj.id,
          hide: false,
          inputType: "checkbox",
          inputValue: obj.value,
          accept: "",
          inputName: "userName",
          placeholder: "Please enter number.",
          label: obj.label,
          autofocus: false,
          disabled: false,
          autocomplete: false,
          readonly: false,
          validator: {
            isRequired: true,
            arrayErrors: [],
            arrayFunctions: [DynamicFromValidator.checkBoxEmpty],
          },
        };
        break;
        
        
        
    
     
        case 'select':
        newObj =  {
          uniqueValue: "8",
          hide: false,
          inputType: "select",
          inputValue: obj.value,
          accept: "",
          inputName: "select",
          options: ["Car", "Bike", "Bus", "Train"],
          placeholder: "Please enter number.",
          label: obj.label,
          autofocus: false,
          disabled: false,
          autocomplete: false,
          readonly: false,
          validator: {
            isRequired: true,
            arrayErrors: [],
            arrayFunctions: [DynamicFromValidator.checkSelectEmpty],
          },
        };
        break;
        
        
    
      default:
        break;
    }
    return newObj;
  }

  const fetchData = ()=>{
    let serverData = [
      {
        id:'1',
        inputType:'text',
        label:'userName',
        value:'Salman'
      },
      {
        id:'2',
        inputType:'email',
        label:'Email',
        value:'salman@gmail.com'
      },
      {
        id:'3',
        inputType:'number',
        label:'Number',
        value:'10'
      },
      {
        id:'4',
        inputType:'checkbox',
        label:'Alive',
        value:'true'
      },
      {
        id:'5',
        inputType:'select',
        label:'Select Vehicle',
        value:'Bike',
        options:["Car", "Bike", "Bus", "Train"],
      },
      {
        id:'6',
        inputType:'text',
        label:'CusinName',
        value:'Fizan',
      },
    ];

    serverData = serverData.map(item=>convertDbToForm(item));
    setInputArr(serverData);
  }


  // useEffect(() => {
  //   setTimeout(() => {
      
  //   }, 300);
  // }, []);

  return (
    <div className="home">
<h1>Dynamic Case</h1>

      <button className="btn btn-primary" onClick={fetchData}>FetchData</button>
      <DynamicFrom
        submitUrl="#"
        submitCallBack={() => console.log("Submitted-------------->")}
        formenctype="text/plain"
        formmethod="get"
        inputArrDefault={inputArr}
        // dataType={{
        //   name:{
        //     type:'text',
        //   },
        //   email:{
        //     type:'email',
        //   },
        //   address:{
        //     type:'text',
        //   },
        //   validate:{
        //     type:'checkbox',
        //   },
        //   discription:{
        //     type:'text',
        //   },
        // }}
      />


      <hr />
      <hr />
      <hr />
<h1>Static Case</h1>
      <DynamicFrom
        submitUrl="#"
        submitCallBack={() => console.log("Submitted-------------->")}
        formenctype="text/plain"
        formmethod="get"
        inputArrDefault={[
          // text
          {
            uniqueValue: "1",
            inputType: "text",
            inputValue: "",
            inputName: "userName",
            placeholder: "Please enter name.",
            label: "Name",
            autofocus: false,
            disabled: false,
            autocomplete: false,
            readonly: false,
            callBack:()=>{
              console.log('---------- I am callback-----------',);
            },
            validator: {
              isRequired: true,
              arrayErrors: [],
              arrayFunctions: [
                DynamicFromValidator.checkEmpty,
                DynamicFromValidator.maxLength(20),
                DynamicFromValidator.minLength(10),
                // DynamicFromValidator.emailValidation,
              ],
            },
          },

          // email
          {
            uniqueValue: "2",
            inputType: "email",
            inputValue: "",
            inputName: "userEmail",
            placeholder: "Please enter email.",
            label: "Email",
            autofocus: false,
            disabled: false,
            callBack:()=>{
              console.log('---------- I am callback 2-----------',);
            },
            autocomplete: false,
            readonly: false,
            validator: {
              isRequired: true,
              arrayErrors: [],
              arrayFunctions: [
                DynamicFromValidator.checkEmpty,
                DynamicFromValidator.emailValidation,
              ],
            },
          },

          // number

          {
            uniqueValue: "3",
            hide: false,
            inputType: "number",
            inputValue: "0",
            inputName: "userNumber",
            placeholder: "Please enter name.",
            label: "Name",
            autofocus: false,
            disabled: false,
            autocomplete: false,
            readonly: false,
            validator: {
              isRequired: true,
              arrayErrors: [],
              arrayFunctions: [
                DynamicFromValidator.checkEmpty,
                DynamicFromValidator.maxNumber(10),
                DynamicFromValidator.miniumNumber(5),
              ],
            },
          },

          // file

          {
            uniqueValue: "4",
            hide: false,
            inputType: "file",
            multiple: true,
            accept: "",
            // fileTypes:['png','jpg','jpeg','mp4','mkv','webp'],
            inputName: "userFile",
            placeholder: "Please enter number.",
            label: "Name",
            autofocus: false,
            disabled: false,
            autocomplete: false,
            readonly: false,
            validator: {
              isRequired: true,
              arrayErrors: [],
              arrayFunctions: [
                DynamicFromValidator.checkFileEmpty,
                DynamicFromValidator.maxFiles(5),
                DynamicFromValidator.minFiles(2),
                DynamicFromValidator.validFileTypes([
                  "png",
                  "jpg",
                  "jpeg",
                  "mp4",
                  // "mkv",
                  // "webp",
                ]),
              ],
            },
          },

          // checkBox

          {
            uniqueValue: "5",
            hide: false,
            inputType: "checkbox",
            inputValue: "",
            accept: "",
            inputName: "Alive",
            placeholder: "Please enter number.",
            label: "Fine",
            autofocus: false,
            disabled: false,
            autocomplete: false,
            readonly: false,
            validator: {
              isRequired: true,
              arrayErrors: [],
              arrayFunctions: [DynamicFromValidator.checkBoxEmpty],
            },
          },

          // radio

          {
            uniqueValue: "6",
            hide: false,
            inputType: "radio",
            inputValue: "Bad",
            accept: "",
            inputName: "type",
            placeholder: "Please enter number.",
            label: "Bad",
            autofocus: false,
            disabled: false,
            autocomplete: false,
            readonly: false,
            validator: {
              isRequired: true,
              arrayErrors: [],
              arrayFunctions: [DynamicFromValidator.checkBoxEmpty],
            },
          },
          // radio

          {
            uniqueValue: "6",
            hide: false,
            inputType: "radio",
            inputValue: 'Good',
            accept: "",
            inputName: "type",
            placeholder: "Please enter number.",
            label: "Good",
            autofocus: false,
            disabled: false,
            autocomplete: false,
            readonly: false,
            validator: {
              isRequired: true,
              arrayErrors: [],
              arrayFunctions: [DynamicFromValidator.checkBoxEmpty],
            },
          },

          // select

          {
            uniqueValue: "8",
            hide: false,
            inputType: "select",
            inputValue: false,
            accept: "",
            inputName: "select",
            options: ["Car", "Bike", "Bus", "Train"],
            placeholder: "Please enter number.",
            label: "Select",
            autofocus: false,
            disabled: false,
            autocomplete: false,
            readonly: false,
            validator: {
              isRequired: true,
              arrayErrors: [],
              arrayFunctions: [DynamicFromValidator.checkSelectEmpty],
            },
          },
        ]}
      />
    </div>
  );
};

export default Home;

/*



Make a form generator component

    Component should recevie a prop called fields from which it should be able to render a form
    Prop for form submit url.
    Should be able to handle form submission with callback as well

    Should support all input types text,number,email,file,date,checkbox,radio,select 
    Should be able to support all attribute of an input type
    Should be able to handle validations (not the html attirbute validation but the validation with JS)
    Should be able to support all input change handlers with callbacks
    ------
    This component should be able to handle the edit case as well.
Where it get the data from props or inside the component and set the data on form





*/
