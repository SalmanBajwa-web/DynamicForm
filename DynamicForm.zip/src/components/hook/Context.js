import React, {
  useContext,
  useEffect,
  useState,
  useReducer,
  useCallback,
} from "react";

const AppContext = React.createContext();

export const AppProvider = ({ children }) => {
  // ############### state
  // ############func
  // ###########effect

  return (
    <AppContext.Provider
      value={{
       
      }}
    >
      {children}
    </AppContext.Provider>
  );
};
export const useGlobalContext = () => {
  return useContext(AppContext);
};
