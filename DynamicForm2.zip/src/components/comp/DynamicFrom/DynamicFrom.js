import React, { useState, useEffect } from "react";

/**
 *
 * @param {String} submitUrl - A submiting url
 * @param {Function} submitCallBack - A callback from From
 * @param {String} formenctype - Enctype for form
 * @param {String} formmethod - Method GET,POST,Put,etc
 * @param {Array} [inputArr=[{label: "",placeholder:'',}]] - A submiting url
 *
 * @returns {JSX}
 */

const defaultInputArr = [
  {
    uniqueValue: "1",
    inputType: "text",
    inputValue: "",
    inputName: "userName",
    placeholder: "Please enter name.",
    label: "Name",
    autofocus: false,
    disabled: false,
    autocomplete: false,
    readonly: false,
    validator: {
      isRequired: true,
      arrayErrors: [],
      arrayFunctions: [
        // minium length greater than 5
        (value) => {
          if (value.length < 5) {
            return {
              error: true,
              message: "Length should be greater than 5",
            };
          } else {
            return {
              error: false,
              message: "",
            };
          }
        },
      ],
    },
  },
  {
    uniqueValue: "1",
    inputType: "text",
    inputValue: "",
    inputName: "userName",
    placeholder: "Please enter name.",
    label: "Email",
    autofocus: false,
    disabled: false,
    autocomplete: false,
    readonly: false,
    validator: {
      isRequired: true,
      arrayErrors: [],
      arrayFunctions: [
        // minium length greater than 5
        (value) => {
          if (value.indexOf("@") === -1) {
            return {
              error: true,
              message: "Please enter valid email",
            };
          } else {
            return {
              error: false,
              message: "",
            };
          }
        },
      ],
    },
  },
];

const DynamicFrom = ({
  submitUrl,
  submitCallBack,
  formenctype,
  formmethod,
  inputObjDefault,
  dataType,
}) => {
  // ################## state
  const [inputArr, setInputArr] = useState([]);
  // ################## func
  const validateInputs = () => {
    let isGood = false;
    let newInputArr = [...inputArr];
    newInputArr = newInputArr.map((inputObj) => {
      // if not required
      if (!inputObj.validator.isRequired) return inputObj;
      inputObj.validator.arrayErrors = [];
      inputObj.validator.arrayFunctions.forEach((validatorFunc) => {
        const validatorObj = validatorFunc(inputObj.inputValue);
        if (validatorObj.error) {
          inputObj.validator.arrayErrors.push(validatorObj);
        }
      });

      // console.log("Error :", inputObj);
      return inputObj;
    });

    setInputArr(newInputArr);
    let errorArr = [];
    newInputArr.forEach((item) => {
      errorArr = [...errorArr, ...item.validator.arrayErrors];
    });
    console.log("errorArr :", errorArr);
    if (errorArr.length === 0) {
      isGood = true;
    }
    return isGood;
  };

  const whenSubmit = (ev) => {
    ev.preventDefault();
    // validation
    let isSubmit = validateInputs();
    // submit form
    if (isSubmit) {
      const obj = inputArr.reduce((accu, item) => {
        accu[item.inputName] = item.inputValue;
        return accu;
      }, {});

      console.log("submitForm :", obj);
    }
  };
  const handleInputChange = (val, inputName) => {
    //   console.log('handleInputChange :',val,inputName);
    let copyInputArr = [...inputArr];
    copyInputArr.map((inputObj) => {
      if (inputObj.inputName === inputName) {
        inputObj.inputValue = val;
        return inputObj;
      }
      return inputObj;
    });
    setInputArr(copyInputArr);
  };

  const convertDbToForm = (dataTypeObj, inputObjDefault) => {
    let convertedArr = [];
    for (const i in dataTypeObj) {
      if (Object.hasOwnProperty.call(dataTypeObj, i)) {
        const element = dataTypeObj[i];
        element.inputValue = inputObjDefault[i];
        element.inputName = i;
        convertedArr.push(element);
      }
    }
    console.log("convertedArr :", convertedArr);
    return convertedArr;
    // let newObj = obj;
    // switch (obj.inputType) {
    //   case 'text':
    //     newObj =  {
    //       uniqueValue: obj.id,
    //       inputType: "text",
    //       inputValue: obj.value,
    //       inputName: "userName",
    //       placeholder: "Please enter name.",
    //       label: obj.label,
    //       autofocus: false,
    //       disabled: false,
    //       autocomplete: false,
    //       readonly: false,
    //       validator: {
    //         isRequired: true,
    //         arrayErrors: [],
    //         arrayFunctions: [
    //           DynamicFromValidator.checkEmpty,
    //           DynamicFromValidator.maxLength(20),
    //           DynamicFromValidator.minLength(10),
    //           DynamicFromValidator.checkLetterExists("-"),
    //           // DynamicFromValidator.emailValidation,
    //         ],
    //       },
    //     };
    //     break;

    //     case 'email':
    //     newObj =  {
    //       uniqueValue: obj.id,
    //       inputType: "email",
    //       inputValue: obj.value,
    //       inputName: "Email",
    //       placeholder: "Please enter email.",
    //       label: obj.label,
    //       autofocus: false,
    //       disabled: false,
    //       autocomplete: false,
    //       readonly: false,
    //       validator: {
    //         isRequired: true,
    //         arrayErrors: [],
    //         arrayFunctions: [
    //           DynamicFromValidator.checkEmpty,
    //           DynamicFromValidator.maxLength(20),
    //           DynamicFromValidator.minLength(10),
    //           DynamicFromValidator.checkLetterExists("-"),
    //           // DynamicFromValidator.emailValidation,
    //         ],
    //       },
    //     };
    //     break;

    //     case 'number':
    //     newObj =  {
    //       uniqueValue: obj.id,
    //       inputType: "number",
    //       inputValue: obj.value,
    //       inputName: "number",
    //       placeholder: "Please enter number.",
    //       label: obj.label,
    //       autofocus: false,
    //       disabled: false,
    //       autocomplete: false,
    //       readonly: false,
    //       validator: {
    //         isRequired: true,
    //         arrayErrors: [],
    //         arrayFunctions: [
    //           DynamicFromValidator.checkEmpty,
    //           DynamicFromValidator.maxLength(20),
    //           DynamicFromValidator.minLength(10),
    //           DynamicFromValidator.checkLetterExists("-"),
    //           // DynamicFromValidator.emailValidation,
    //         ],
    //       },
    //     };
    //     break;

    //     case 'checkbox':
    //     newObj =    {
    //       uniqueValue: obj.id,
    //       hide: false,
    //       inputType: "checkbox",
    //       inputValue: obj.value,
    //       accept: "",
    //       inputName: "userName",
    //       placeholder: "Please enter number.",
    //       label: obj.label,
    //       autofocus: false,
    //       disabled: false,
    //       autocomplete: false,
    //       readonly: false,
    //       validator: {
    //         isRequired: true,
    //         arrayErrors: [],
    //         arrayFunctions: [DynamicFromValidator.checkBoxEmpty],
    //       },
    //     };
    //     break;

    //     case 'select':
    //     newObj =  {
    //       uniqueValue: "8",
    //       hide: false,
    //       inputType: "select",
    //       inputValue: obj.value,
    //       accept: "",
    //       inputName: "select",
    //       options: ["Car", "Bike", "Bus", "Train"],
    //       placeholder: "Please enter number.",
    //       label: obj.label,
    //       autofocus: false,
    //       disabled: false,
    //       autocomplete: false,
    //       readonly: false,
    //       validator: {
    //         isRequired: true,
    //         arrayErrors: [],
    //         arrayFunctions: [DynamicFromValidator.checkSelectEmpty],
    //       },
    //     };
    //     break;

    //   default:
    //     break;
    // }
    // return newObj;
  };

  // ################## effect
  useEffect(() => {
    setInputArr(convertDbToForm(dataType, inputObjDefault));
  }, [dataType]);

  console.log("DynamicForm render inpuArr log:", inputArr);
  return (
    <div className="dynamicForm">
      <form onSubmit={whenSubmit}>
        {inputArr.map((item, index) => {
          let returnBox = undefined;
          switch (item.inputType) {
            case "text":
              returnBox = (
                <div className="inputBox from-group" key={index+item.inputName}>
                  <p className="mb-0">{item.inputName}</p>
                  <input
                    className="form-control"
                    type="text"
                    value={item.inputValue}
                    name={item.inputName}
                    placeholder={item.placeholder}
                    // autoComplete={item.autocomplete==='false'?false:true}
                    readOnly={item.readonly}
                    disabled={item.disabled}
                    autoFocus={item.autofocus}
                    onChange={(ev) => {
                      handleInputChange(ev.target.value, item.inputName);
                      if (item.callBack) {
                        item.callBack();
                      }
                    }}
                  />
                  {item.validator.arrayErrors.length > 0 &&
                    item.validator.arrayErrors.map((item, index) => {
                      return (
                        <div className="box" key={item + index}>
                          <span className="badge badge-danger">
                            {item.message}
                          </span>
                        </div>
                      );
                    })}
                </div>
              );
              break;

            case "email":
              returnBox = (
                <div className="inputBox from-group" key={index+item.inputName}>
                  <p className="mb-0">{item.inputName}</p>
                  <input
                    className="form-control"
                    type="text"
                    value={item.inputValue}
                    name={item.inputName}
                    placeholder={item.placeholder}
                    // autoComplete={item.autocomplete==='false'?false:true}
                    readOnly={item.readonly}
                    disabled={item.disabled}
                    autoFocus={item.autofocus}
                    onChange={(ev) => {
                      handleInputChange(ev.target.value, item.inputName);
                      if (item.callBack) {
                        item.callBack();
                      }
                    }}
                  />
                  {item.validator.arrayErrors.length > 0 &&
                    item.validator.arrayErrors.map((item, index) => {
                      return (
                        <div className="box" key={item + index}>
                          <span className="badge badge-danger">
                            {item.message}
                          </span>
                        </div>
                      );
                    })}
                </div>
              );
              break;

            case "number":
              returnBox = (
                <div className="inputBox from-group" key={index+item.inputName}>
                  <p className="mb-0">{item.inputName}</p>
                  <input
                    className="form-control"
                    type="number"
                    value={item.inputValue}
                    name={item.inputName}
                    placeholder={item.placeholder}
                    // autoComplete={item.autocomplete==='false'?false:true}

                    readOnly={item.readonly}
                    disabled={item.disabled}
                    autoFocus={item.autofocus}
                    onChange={(ev) => {
                      handleInputChange(ev.target.value, item.inputName);
                      // item.callBack();
                      if (item.callBack) {
                        item.callBack();
                      }
                    }}
                  />
                  {item.validator.arrayErrors.length > 0 &&
                    item.validator.arrayErrors.map((item, index) => {
                      return (
                        <div className="box" key={item + index}>
                          <span className="badge badge-danger">
                            {item.message}
                          </span>
                        </div>
                      );
                    })}
                </div>
              );
              break;

            case "select":
              returnBox = (
                <div className="inputBox from-group" key={index+item.inputName}>
                  <p className="mb-0">{item.inputName}</p>
                  <select
                    className="form-control"
                    defaultValue={item.inputValue.selected}
                    name={item.inputName}
                    placeholder={item.placeholder}
                    // autoComplete={item.autocomplete==='false'?false:true}

                    readOnly={item.readonly}
                    disabled={item.disabled}
                    autoFocus={item.autofocus}
                    onChange={(ev) => {
                      handleInputChange({...item.inputValue,selected:ev.target.value}, item.inputName);
                      // item.callBack();
                      if (item.callBack) {
                        item.callBack();
                      }
                    }}
                  >
                    {item.inputValue.options.map((item, index) => {
                      return (
                        <option key={item + index} value={item}>
                          {item}
                        </option>
                      );
                    })}
                  </select>

                  {item.validator.arrayErrors.length > 0 &&
                    item.validator.arrayErrors.map((item, index) => {
                      return (
                        <div className="box" key={item + index}>
                          <span className="badge badge-danger">
                            {item.message}
                          </span>
                        </div>
                      );
                    })}
                </div>
              );
              break;



            case "checkbox":
              returnBox = (
                <div className="inputBox from-group" key={index+item.inputName}>
                  <p className="mb-0">{item.inputName}</p>
                  <input
                    className="form-control"
                    type="checkbox"
                    // value={item.inputValue}
                    checked={item.inputValue==='false'?false:true}
                    
                    // {item.inputValue==='true'?'checked':null}
                    name={item.inputName}
                    placeholder={item.placeholder}
                    // autoComplete={item.autocomplete==='false'?false:true}
                    readOnly={item.readonly}
                    disabled={item.disabled}
                    autoFocus={item.autofocus}
                    onChange={(ev) => {
                      handleInputChange(ev.target.checked, item.inputName);
                      if (item.callBack) {
                        item.callBack();
                      }
                      // item.callBack();
                    }}
                  />
                  {item.validator.arrayErrors.length > 0 &&
                    item.validator.arrayErrors.map((item, index) => {
                      return (
                        <div className="box" key={item + index}>
                          <span className="badge badge-danger">
                            {item.message}
                          </span>
                        </div>
                      );
                    })}
                </div>
              );
              break;

              
            case "radio":
              returnBox = (
                <div className="radioOuterBox" key={index+item.inputName}>
                  {item.inputValue.options.map((radioItem,index) => {
                    return (
                      <div className="inputBox from-group" key={index+radioItem}>
                        <p className="mb-0">{radioItem}</p>

                        <input
                          className="form-control"
                          type="radio"
                          value={radioItem}
                          checked={item.inputValue.selected===radioItem}
                          name={item.inputName}
                          placeholder={item.placeholder}
                          // autoComplete={item.autocomplete.toString()}
                    // autoComplete={item.autocomplete==='false'?false:true}

                          readOnly={item.readonly}
                          disabled={item.disabled}
                          autoFocus={item.autofocus}
                          onChange={(ev) => {
                            handleInputChange(
                              {...item.inputValue,selected:ev.target.value},
                              item.inputName,
                            );

                            // item.callBack();
                            if (item.callBack) {
                              item.callBack();
                            }
                          }}
                        />
                      </div>
                    );
                  })}

                  {item.validator.arrayErrors.length > 0 &&
                    item.validator.arrayErrors.map((item, index) => {
                      return (
                        <div className="box" key={item + index}>
                          <span className="badge badge-danger">
                            {item.message}
                          </span>
                        </div>
                      );
                    })}
                </div>
              );
              break;


            case "file":
              returnBox = (
                <div className="inputBox from-group" key={index+item.inputName}>
                  <p className="mb-0">{item.label}</p>
                  <input
                    className="form-control"
                    type="file"
                    accept={item.accept}
                    multiple={item.multiple}
                    name={item.inputName}
                    placeholder={item.placeholder}
                    // autoComplete={item.autocomplete==='false'?false:true}

                    readOnly={item.readonly}
                    disabled={item.disabled}
                    autoFocus={item.autofocus}
                    onChange={(ev) => {
                      handleInputChange(ev.target.files, item.inputName);
                      if (item.callBack) {
                        item.callBack();
                      }
                    }}
                  />
                  {item.validator.arrayErrors.length > 0 &&
                    item.validator.arrayErrors.map((item, index) => {
                      return (
                        <div className="box" key={item + index}>
                          <span className="badge badge-danger">
                            {item.message}
                          </span>
                        </div>
                      );
                    })}
                </div>
              );
              break;

            default:
              returnBox = "input type of one input not matched";
              break;
          }

          return returnBox;
        })}

        <button type="submit" className="btn btn-primary mt-3 btn-block">
          Submit
        </button>
      </form>
    </div>
  );
};

export default DynamicFrom;

/**
 *
 * @returns {Object} {maxLength,minLength,max,min,checkEmpty} - Bunch of validations functions
 */
export const DynamicFromValidator = {
  /**
   *
   * @param {String}  - String value for current input value.Number value for number of length varify.
   * @param {Number}  - Number value for number of length varify.
   * @returns {Object} {error,message} - Value if pass validation
   */
  maxLength: (number) => (val) => {
    const copyVal = val.trim();
    if (copyVal.length > number) {
      return {
        error: true,
        message: `Letters length shuld be less than "${number}"`,
      };
    } else {
      return {
        error: false,
        message: ``,
      };
    }
  },

  /**
   *
   * @param {String}  - String value for current input value.Number value for number of length varify.
   * @param {Number}  - Number value for number of length varify.
   * @returns {Object} {error,message} - Value if pass validation
   */
  minLength: (number) => (val) => {
    const copyVal = val.trim();
    if (copyVal.length < number) {
      return {
        error: true,
        message: `Letters length shuld be greater than "${number}"`,
      };
    } else {
      return {
        error: false,
        message: ``,
      };
    }
  },

  /**
   *
   * @param {String}  - String value for current input value.Number value for number of length varify.
   * @param {Number}  - Number value for number of length varify.
   * @returns {Object} {error,message} - Value if pass validation
   */
  maxNumber: (number) => (val) => {
    const copyVal = val.trim();
    if (copyVal > number) {
      return {
        error: true,
        message: `Please enter number less than "${number}"`,
      };
    } else {
      return {
        error: false,
        message: ``,
      };
    }
  },
  /**
   *
   * @param {String}  - String value for current input value.Number value for number of length varify.
   * @param {Number}  - Number value for number of length varify.
   * @returns {Object} {error,message} - Value if pass validation
   */
  miniumNumber: (number) => (val) => {
    const copyVal = val.trim();
    if (copyVal < number) {
      return {
        error: true,
        message: `Please enter number greater than "${number}"`,
      };
    } else {
      return {
        error: false,
        message: ``,
      };
    }
  },

  /**
   *
   * @param {String}  - String value check if exists in input.
   * @returns {Object} {error,message} - Value if pass validation
   */
  shuldNotContainNumbers: (val) => {
    const copyVal = val.trim();
    if (/\d/.test(copyVal)) {
      return {
        error: true,
        message: `Input shuld not contain Numbers`,
      };
    } else {
      return {
        error: false,
        message: ``,
      };
    }
  },
  /**
   *
   * @param {String}  - String value check if exists in input.
   * @returns {Object} {error,message} - Value if pass validation
   */
  shuldNotContainLetters: (val) => {
    const copyVal = val.trim();
    if (/\w/.test(copyVal)) {
      return {
        error: true,
        message: `Input shuld not contain Letters`,
      };
    } else {
      return {
        error: false,
        message: ``,
      };
    }
  },

  /**
   *
   * @param {String}  - String value for current input value.Number value for number of length varify.
   * @param {String}  - String value check if exists in input.
   * @returns {Object} {error,message} - Value if pass validation
   */
  checkLetterExists: (letter) => (val) => {
    const copyVal = val.trim();
    if (copyVal.indexOf(letter) === -1) {
      return {
        error: true,
        message: `Input shuld contain letter "${letter}"`,
      };
    } else {
      return {
        error: false,
        message: ``,
      };
    }
  },

  /**
   * - Check if input is empty or not.
   * @returns {Object} {error,message} - Value if pass validation
   */
  checkEmpty: (val) => {
    const copyVal = val.trim();
    if (!copyVal) {
      return {
        error: true,
        message: `Please fill this input.`,
      };
    } else {
      return {
        error: false,
        message: ``,
      };
    }
  },

  /**
   * - Check if input is empty or not.
   * @returns {Object} {error,message} - Value if pass validation
   */
  checkBoxEmpty: (val) => {
    if (!val.selected) {
      return {
        error: true,
        message: `Please fill this input.`,
      };
    } else {
      return {
        error: false,
        message: ``,
      };
    }
  },

  /**
   * - Check if input is empty or not.
   * @returns {Object} {error,message} - Value if pass validation
   */
  checkSelectEmpty: (val) => {
    if (!val) {
      return {
        error: true,
        message: `Please fill this input.`,
      };
    } else {
      return {
        error: false,
        message: ``,
      };
    }
  },

  /**
   * - Check if input is empty or not.
   * @returns {Object} {error,message} - Value if pass validation
   */
  checkFileEmpty: (val) => {
    if (!val) {
      return {
        error: true,
        message: `Please add file !`,
      };
    }

    if (val.length > 0) {
      return {
        error: false,
        message: ``,
      };
    } else {
      return {
        error: true,
        message: `Please add file !`,
      };
    }
  },

  /**
   * - Check max files of input.
   * @returns {Object} {error,message} - Value if pass validation
   */
  maxFiles: (number) => (val) => {
    if (!val) {
      return {
        error: true,
        message: `Please enter less files than ${number} !`,
      };
    }

    if (val.length > number) {
      return {
        error: true,
        message: `Please enter less files than ${number} !`,
      };
    } else {
      return {
        error: false,
        message: ``,
      };
    }
  },

  /**
   * - Check min files of input.
   * @returns {Object} {error,message} - Value if pass validation
   */
  minFiles: (number) => (val) => {
    if (!val) {
      return {
        error: true,
        message: `Please enter more files than ${number} !`,
      };
    }

    if (val.length < number) {
      return {
        error: true,
        message: `Please enter more files than ${number} !`,
      };
    } else {
      return {
        error: false,
        message: ``,
      };
    }
  },

  /**
   * - Check file types suported.
   * @returns {Object} {error,message} - Value if pass validation
   */
  validFileTypes: (fileTypeArray) => (val) => {
    if (!val) {
      return {
        error: true,
        message: `Valid file types are ${fileTypeArray.join(",")} !`,
      };
    }

    let goodFile = false;
    goodFile = Array.from(val).every((item) => {
      const ext = item.type.slice(item.type.indexOf("/") + 1);

      const fileTypeString = fileTypeArray.join(" ");
      // console.log('ext :',ext,"fileTypeString :",fileTypeString,ext.indexOf(fileTypeString) > -1);
      // return fileTypeArray.every(item=>item.indexOf(ext) > -1);
      return fileTypeString.indexOf(ext) > -1;
    });

    if (goodFile) {
      return {
        error: false,
        message: ``,
      };
    } else {
      return {
        error: true,
        message: `File type is not Valid.Supported types are ${fileTypeArray.join(
          ","
        )} !`,
      };
    }
  },

  /**
   * - Validate email
   * @returns {Object} {error,message} - Value if pass validation
   */
  emailValidation: (val) => {
    const copyVal = val.trim();
    if (
      !/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/gim.test(
        copyVal.toLowerCase()
      )
    ) {
      return {
        error: true,
        message: `Please enter valid email`,
      };
    } else {
      return {
        error: false,
        message: ``,
      };
    }
  },
};

/*
Type text:
label =  label for input
name = name attribue for input
placeholder = placholder value for input
value = a value for input
autofocus = automatically focus input

*/

/*


  //  ########## refrence

  //   const {
  //     label,
  //     placeholder,
  //     inputType,
  //     inputName,
  //     inputValue,
  //     autofocus,
  //     disabled,
  //     autocomplete,
  //     readonly,
  //     step,
  //     // for input type file
  //     multiple,
  //   } = inputArr;


Make a form generator component

    Component should recevie a prop called fields from which it should be able to render a form
    Prop for form submit url.
    Should be able to handle form submission with callback as well


    Should support all input types text,number,email,file,date,checkbox,radio,select 
    Should be able to support all attribute of an input type
    Should be able to handle validations (not the html attirbute validation but the validation with JS)
    Should be able to support all input change handlers with callbacks

***************
elements hide when not expections match
    ------
    This component should be able to handle the edit case as well.
Where it get the data from props or inside the component and set the data on form

[png,jpg,jpeg,mp4]



*/
