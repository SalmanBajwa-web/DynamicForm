// import { useEffect } from 'react/cjs/react.development'
// import DynamicFrom from '../../comp/DynamicFrom/DynamicFrom'
const Detail = () => {
  // useState
  // useEffect
  return (
    <div onClick={(ev)=>{

    }}>


    </div>
  )
}

export default Detail